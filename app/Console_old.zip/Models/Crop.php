<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Crop extends Model
{
    use HasFactory;
    
    protected $fillable = [
        'crop_name',
      
    ];
    
    /**
     * Get the outlet that this crop belongs to.
     */
    
    
    /**
     * Get the village that this crop belongs to.
     */
    
}
