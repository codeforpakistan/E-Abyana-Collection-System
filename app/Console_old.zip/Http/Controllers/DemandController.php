<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DemandController extends Controller
{
    public function Dstatement(){

        return view('DemandStatement.AddDemendStatement');
   
}
}
