$(function(){
	$("#addClass").on("click", function (e) {
		$('#qnimate').addClass('popup-box-on');
	});

	$("#removeClass").on("click", function (e) {
		$('#qnimate').removeClass('popup-box-on');
	});
})