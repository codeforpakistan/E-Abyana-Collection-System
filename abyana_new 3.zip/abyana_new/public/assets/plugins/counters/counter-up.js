$( function() {
		$('.counter').countUp();
	} );