(function($) {
    "use strict";
	$('#lightgallery').lightGallery();
})(jQuery);